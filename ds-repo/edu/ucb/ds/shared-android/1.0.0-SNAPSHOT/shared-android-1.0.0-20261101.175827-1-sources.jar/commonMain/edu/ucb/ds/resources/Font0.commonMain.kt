@file:OptIn(InternalResourceApi::class)

package edu.ucb.ds.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/edu.ucb.ds.resources/"

@delegate:ResourceContentHash(-2_069_567_539)
internal val Res.font.inter_bold: FontResource by lazy {
      FontResource("font:inter_bold", setOf(
        ResourceItem(setOf(), "${MD}font/inter_bold.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_399_436_411)
internal val Res.font.inter_medium: FontResource by lazy {
      FontResource("font:inter_medium", setOf(
        ResourceItem(setOf(), "${MD}font/inter_medium.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-996_196_793)
internal val Res.font.inter_regular: FontResource by lazy {
      FontResource("font:inter_regular", setOf(
        ResourceItem(setOf(), "${MD}font/inter_regular.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(374_310_001)
internal val Res.font.inter_semibold: FontResource by lazy {
      FontResource("font:inter_semibold", setOf(
        ResourceItem(setOf(), "${MD}font/inter_semibold.ttf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("inter_bold", Res.font.inter_bold)
  map.put("inter_medium", Res.font.inter_medium)
  map.put("inter_regular", Res.font.inter_regular)
  map.put("inter_semibold", Res.font.inter_semibold)
}
