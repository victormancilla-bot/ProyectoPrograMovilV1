@file:OptIn(InternalResourceApi::class)

package edu.ucb.ds.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/edu.ucb.ds.resources/"

@delegate:ResourceContentHash(451_987_200)
internal val Res.font.opensans_bold: FontResource by lazy {
      FontResource("font:opensans_bold", setOf(
        ResourceItem(setOf(), "${MD}font/opensans_bold.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_279_764_764)
internal val Res.font.opensans_extrabold: FontResource by lazy {
      FontResource("font:opensans_extrabold", setOf(
        ResourceItem(setOf(), "${MD}font/opensans_extrabold.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_703_193_065)
internal val Res.font.opensans_regular: FontResource by lazy {
      FontResource("font:opensans_regular", setOf(
        ResourceItem(setOf(), "${MD}font/opensans_regular.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(831_133_216)
internal val Res.font.opensans_semibold: FontResource by lazy {
      FontResource("font:opensans_semibold", setOf(
        ResourceItem(setOf(), "${MD}font/opensans_semibold.ttf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("opensans_bold", Res.font.opensans_bold)
  map.put("opensans_extrabold", Res.font.opensans_extrabold)
  map.put("opensans_regular", Res.font.opensans_regular)
  map.put("opensans_semibold", Res.font.opensans_semibold)
}
